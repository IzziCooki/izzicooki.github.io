interface Project {
  title: string;
  desc: string;
  image: string;
  link: string;
  details: string;
}

let currentPage: number = 1;
const projectsPerPage: number = 3;
let projectData: Project[] = [];

function fetchProjects(): void {
  fetch('data.json')
    .then(response => {
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      return response.json();
    })
    .then((data: Project[]) => {
      projectData = data;
      renderProjects();
    })
    .catch(error => {
      console.error('Error loading project data:', error);
      const container = document.querySelector<HTMLDivElement>('.projects');
      if (container) {
        container.innerHTML = '<p class="error-message">Failed to load projects. Please try again later.</p>';
      }
    });
}

function renderProjects(): void {
  const container = document.querySelector<HTMLDivElement>('.projects');
  if (!container) {
    console.error('Projects container not found');
    return;
  }
  container.innerHTML = '';

  const start = (currentPage - 1) * projectsPerPage;
  const end = start + projectsPerPage;
  const currentProjects = projectData.slice(start, end);

  currentProjects.forEach((proj, i) => {
    const card = document.createElement('div');
    card.className = 'project-card';
    card.style.animationDelay = `${i * 0.2}s`;
    card.innerHTML = `
      <img src="${proj.image}" alt="${proj.title}" class="project-image" loading="lazy" />
      <h3>${proj.title}</h3>
      <p>${proj.desc}</p>
    `;
    container.appendChild(card);
  });

  updatePaginationButtons();
}

function updatePaginationButtons(): void {
  const prevButton = document.querySelector<HTMLButtonElement>('.pagination button:first-child');
  const nextButton = document.querySelector<HTMLButtonElement>('.pagination button:last-child');
  
  if (prevButton) {
    prevButton.disabled = currentPage === 1;
  }
  if (nextButton) {
    nextButton.disabled = currentPage * projectsPerPage >= projectData.length;
  }
}

function setupPagination(): void {
  const pagination = document.querySelector<HTMLDivElement>('.pagination');
  if (!pagination) {
    console.error('Pagination container not found');
    return;
  }

  pagination.addEventListener('click', (e) => {
    const target = e.target as HTMLElement;
    if (!target || !target.textContent) return;

    if (target.textContent.includes('Next') && currentPage * projectsPerPage < projectData.length) {
      currentPage++;
      renderProjects();
    }
    if (target.textContent.includes('Prev') && currentPage > 1) {
      currentPage--;
      renderProjects();
    }
  });
}

function openProjectPopup(title: string, details: string, link: string, image: string): void {
  const popup = document.getElementById('project-modal') as HTMLDivElement;
  const popupTitle = document.getElementById('popup-title') as HTMLHeadingElement;
  const popupDesc = document.getElementById('popup-desc') as HTMLParagraphElement;
  const popupImageLink = document.getElementById('popup-image-link') as HTMLAnchorElement;
  const popupImage = document.getElementById('popup-image') as HTMLImageElement;

  if (!popup || !popupTitle || !popupDesc || !popupImage || !popupImageLink) {
    console.error('Popup elements not found');
    return;
  }

  // Lock scroll
  document.body.style.overflow = 'hidden';
  
  popupTitle.textContent = title;
  popupDesc.textContent = details;
  popupImage.src = image;
  popupImage.alt = title;
  popupImageLink.href = link;
  popupImageLink.target = "_blank";
  popup.classList.add('active');
}

function closeProjectPopup(): void {
  const popup = document.getElementById('project-modal') as HTMLDivElement;
  if (popup) {
    popup.classList.remove('active');
    // Unlock scroll
    document.body.style.overflow = '';
  }
}

function handleFormSubmit(event: Event): void {
  event.preventDefault();
  const form = event.target as HTMLFormElement;
  const statusDiv = document.getElementById('form-status') as HTMLDivElement;
  
  if (!statusDiv) return;

  statusDiv.textContent = 'Sending message...';
  statusDiv.className = 'form-status sending';

  fetch(form.action, {
    method: 'POST',
    body: new FormData(form)
  })
  .then(response => {
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    statusDiv.textContent = 'Message sent successfully!';
    statusDiv.className = 'form-status success';
    form.reset();
  })
  .catch(error => {
    console.error('Error:', error);
    statusDiv.textContent = 'Message sent successfully';
    statusDiv.className = 'form-status success';
  });
}

document.addEventListener('DOMContentLoaded', () => {
  fetchProjects();
  setupPagination();

  const projectsContainer = document.querySelector('.projects');
  projectsContainer?.addEventListener('click', (e) => {
    const card = (e.target as HTMLElement).closest('.project-card') as HTMLDivElement;
    if (!card) return;

    const title = (card.querySelector('h3') as HTMLHeadingElement)?.textContent || '';
    const clickedTitle = title.trim();

    const project = projectData.find(p => p.title === clickedTitle);
    if (project) {
      openProjectPopup(project.title, project.details, project.link, project.image);
    }
  });

  const closeBtn = document.getElementById('popup-close');
  closeBtn?.addEventListener('click', closeProjectPopup);

  const contactForm = document.querySelector('.contact-form') as HTMLFormElement;
  contactForm?.addEventListener('submit', handleFormSubmit);
});
